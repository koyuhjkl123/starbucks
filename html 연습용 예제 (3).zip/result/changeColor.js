function changeBackground(colorName) {
 document.bgColor=colorName
}
function changeText(colorName) {
 document.fgColor=colorName
}