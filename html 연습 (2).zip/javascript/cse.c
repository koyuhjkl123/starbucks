#include <stdio.h>

int main(void)
{
    printf("이름 : 김진수\n 나이 : 23살\n 성격 : 무덤하다");
}