food = "python's favorite food is per1"

print(food)

print((food[5]))
print(food[12])
print(food[:7])
print(food[:17])

number = 10
day = 'three'
print("I eat %d apples." % number)

bs = 'apple'
print("I eat %s css" % bs)

css = "html, css, javascript"
print("I the %s" % css)
print(css.count('s'))
print((css.find('t')))

pop = 165
print('100 + 65 = %d' % pop)