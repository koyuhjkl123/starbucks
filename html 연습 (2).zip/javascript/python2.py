a = "Life is too shott"
print(a.split())

ac= '1,2,3,4,5,6'
print(ac.split(':'))
print(len(ac))

ab = [1,2,3,4,5]
del ab[3]
print((ab))

ae = ['a','c','e','b']
print(ae.sort())
print(ae)

print(ae.reverse())
print(ae)

print(ae.insert(3,'d'))
print(ae)

# len() 길이