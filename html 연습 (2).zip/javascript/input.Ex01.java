package input;

import java.io.IOException;

public class Ex01 {
    public static void main(String[] args) throws IOException {

        System.out.printf("키고그 입력하고 엔터");

        int keyCode;

        keyCode = System.in.read();
    }
}