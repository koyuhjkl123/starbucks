a = 80
b = 60
c = 50
f = 95
w = 80
c = 65
q = 80
n = 75
m = 100
k = 85

d = (a+b+c+f+w+c+q+n+m+k)/10
print(d)